Some antiviruses can block software, so we recommend disabling them before starting.
Good Luck in earnings!
